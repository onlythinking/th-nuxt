// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/\":[\"content:index.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
