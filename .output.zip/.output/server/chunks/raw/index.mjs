// ROLLUP_NO_REPLACE 
 const index = "{\"parsed\":{\"_path\":\"/\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"试一试\",\"description\":\"\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h1\",\"props\":{\"id\":\"试一试\"},\"children\":[{\"type\":\"text\",\"value\":\"试一试\"}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:index.md\",\"_source\":\"content\",\"_file\":\"index.md\",\"_stem\":\"index\",\"_extension\":\"md\"},\"hash\":\"mzC4mZ8fFU\"}";

export { index as default };
//# sourceMappingURL=index.mjs.map
