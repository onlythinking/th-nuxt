// ROLLUP_NO_REPLACE 
 const contentNavigation = "[{\"title\":\"试一试\",\"_path\":\"/\"}]";

export { contentNavigation as default };
//# sourceMappingURL=content-navigation.mjs.map
