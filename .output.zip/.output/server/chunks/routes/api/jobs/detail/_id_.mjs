import { d as defineEventHandler, g as getRouterParam } from '../../../../runtime.mjs';
import { j as jobs } from '../../../../_/jobs.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import 'node:url';
import '@iconify/utils';
import 'consola/core';
import 'unified';
import 'mdast-util-to-string';
import 'micromark';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';
import 'micromark-util-sanitize-uri';
import 'slugify';
import 'remark-parse';
import 'remark-rehype';
import 'remark-mdc';
import 'remark-emoji';
import 'remark-gfm';
import 'rehype-external-links';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';
import 'detab';
import 'hast-util-to-string';
import 'github-slugger';
import 'ipx';

const _id_ = defineEventHandler(async (event) => {
  const id = Number(getRouterParam(event, "id")) || 1;
  const jobDetail = jobs.find((job) => job.id === id);
  if (!jobDetail) {
    return {
      code: 404,
      message: `Job with ID ${id} not found.`,
      data: null
    };
  }
  return {
    code: 0,
    message: "ok",
    data: jobDetail
  };
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
