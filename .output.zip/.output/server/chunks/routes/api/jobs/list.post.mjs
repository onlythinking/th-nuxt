import { d as defineEventHandler, r as readBody } from '../../../runtime.mjs';
import { j as jobs } from '../../../_/jobs.mjs';
import 'node:http';
import 'node:https';
import 'node:fs';
import 'node:path';
import 'node:url';
import '@iconify/utils';
import 'consola/core';
import 'unified';
import 'mdast-util-to-string';
import 'micromark';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';
import 'micromark-util-sanitize-uri';
import 'slugify';
import 'remark-parse';
import 'remark-rehype';
import 'remark-mdc';
import 'remark-emoji';
import 'remark-gfm';
import 'rehype-external-links';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';
import 'detab';
import 'hast-util-to-string';
import 'github-slugger';
import 'ipx';

const list_post = defineEventHandler(async (event) => {
  const requestBody = await readBody(event);
  const page = Number(requestBody.page) || 1;
  const pageSize = Number(requestBody.pageSize) || 10;
  const keyword = requestBody.keyword || "";
  let filteredJobs = jobs;
  if (keyword) {
    filteredJobs = jobs.filter((job) => {
      return job.jobName.toLowerCase().includes(keyword) || job.type.toLowerCase().includes(keyword);
    });
  }
  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedData = filteredJobs.slice(startIndex, endIndex);
  return {
    code: 0,
    message: "ok",
    data: {
      total: filteredJobs.length,
      // 搜索结果的总记录数
      content: paginatedData
      // 当前页的数据
    }
  };
});

export { list_post as default };
//# sourceMappingURL=list.post.mjs.map
