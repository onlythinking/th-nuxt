const a=()=>({fallbackLocale:"en"});export{a as default};
