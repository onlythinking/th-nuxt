import{d as n,J as e}from"./DaEeV-3K.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
