import{C as e,D as t}from"./DaEeV-3K.js";const i=e((a,o)=>t("/login"));export{i as default};
