import{_ as r}from"./DlAUqK2U.js";import{o as e,c as o}from"./DaEeV-3K.js";const c={};function t(n,s){return e(),o("hr")}const f=r(c,[["render",t]]);export{f as default};
